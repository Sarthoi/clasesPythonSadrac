from setuptools import setup

setup(
name="usuarios",
version="1",
description="Usuarios y sus metodos",
author="Sadrac Araneda",
author_email="saadrak.oai@gmail.com",
packages=["modulo_1"]
)

# setup(
# name="productos",
# version="1",
# description="Productos y sus metodos",
# author="Sadrac Araneda",
# author_email="saadrak.oai@gmail.com",
# packages=["modulo_2"]
# )